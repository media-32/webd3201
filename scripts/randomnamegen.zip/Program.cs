﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RandomNameGenerator
{
    class Program
    {
        static void Main(string[] args)

        {
            string lastnamesFile = @"C:\Users\aaron\source\repos\RandomNameGenerator\RandomNameGenerator\lastnames.txt";
            string femalenamesFile = @"C:\Users\aaron\source\repos\RandomNameGenerator\RandomNameGenerator\FemaleNames.txt";
            string malenamesFile = @"C:\Users\aaron\source\repos\RandomNameGenerator\RandomNameGenerator\MaleNames.txt";

            List<string> lastnames = NameFileReader.GetNames(lastnamesFile);
            List<string> femalenames = NameFileReader.GetNames(femalenamesFile);
            List<string> malenames = NameFileReader.GetNames(malenamesFile);

            List<string> boys =GenerateNames.GenerateListNames(500, malenames, lastnames);

            Program.PrintNames("Boys",boys);
            List<string> girls = GenerateNames.GenerateListNames(500, femalenames, lastnames);
            Program.PrintNames("Girls", girls);
            Console.ReadLine();
        }
        public static void PrintNames (string heading,List<string> names)
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine(heading);
            Console.WriteLine("-----------------------");
            foreach (string name in names) Console.WriteLine(name);
        }
    }


    class NameFileReader
    {
        public NameFileReader ()
        {
        }

        public static List<string> GetNames(string fileName)
        {
            List<string> names = new List<string>();

            if (File.Exists(fileName))
            {
                names.AddRange(File.ReadLines(fileName));
            }
            return names;
        }

    }
    class GenerateNames
    {

        public GenerateNames ()
        {
        }


        public static List<string> GenerateListNames (int numberOfNames, List<string> firstnames, List<string> lastnames)
        {
            Random randomNumber = new Random();
            int firstNameIndex = 0;
            int lastNameIndex = 0;
            string personName = "";
            int femaleSalutationIndex = 0;
            string[] femaleSalutations = new string[] { "miss.", "mrs.", "ms." };
            string adress = "";
            string[] streetname = new string[] { "King","Queen","Simcoe","Wilson","Centre","Young","Victoria","John","Adelaide","Lawrence"};
            string[] streetlast = new string[] {"Ave","rd","st","blv"};
            List<string> listOfNames = new List<string>();
            string[] citynames = new string[] {"Toronto","Oshawa","Ottawa","Ajax","Pickering","Victoria","Vancouver","Calgary","Edmonton","Regina","Winnipeg","Quebec City","Montreal","Frediricton","Charlottetown","Halifax","Sydney","Whitehorse","Yellowknife","Iqaluit"};
            string city = "";
            string[] letters = new string[] { "A", "B", "C", "E", "G", "H", "J", "K", "L", "M", "N", "P", "R", "S", "T", "V", "W", "X", "Y", "Z" };
            string postal = "";
            string phone="";
            string fax = "";
            int contact = 0;

            while (listOfNames.Count < numberOfNames)
            {

                personName = "insert into Persons (salutations,first_name,last_name,street_address1,street_address2,city,province,postal_code,primary_phone_number,secondary_phone_number,fax_number,preffered_contact_method) values (";
                firstNameIndex = randomNumber.Next(0,firstnames.Count);
                lastNameIndex = randomNumber.Next(0,lastnames.Count);
                if (firstnames[0].Equals("ABBEY") == true)
                {
                    femaleSalutationIndex = randomNumber.Next(0, 3);
                    personName =personName+"'"+ femaleSalutations[femaleSalutationIndex]+"','"+firstnames[firstNameIndex] + "','" + lastnames[lastNameIndex]+"'";                    
                }
                else if(firstnames[0].Equals("AARON")==true)
                {
                    personName=personName+ "'mr.'" + ",'" + firstnames[firstNameIndex] + "','" + lastnames[lastNameIndex]+"'";
                }

                adress =",'" +randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10)+" "+streetname[randomNumber.Next(0,10)]+" "+streetlast[randomNumber.Next(0,4)];
                personName = personName + adress+"'";

                if (randomNumber.Next(0,2)==2)
                {
                    adress = "," + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + " " + streetname[randomNumber.Next(0, 10)] +" "+ streetlast[randomNumber.Next(0, 4)];
                    personName = personName + "'"+adress+"'";
                }
                   else
                {
                    personName = personName + ",'null'";
                }

                city =citynames[randomNumber.Next(0, 20)];
                personName = personName + ",'" + city+"'";

                if (city.Equals("Toronto") || city.Equals("Oshawa") || city.Equals("Ajax") || city.Equals("Ottawa") || city.Equals("Pickering"))
                {
                    personName = personName + ",'ON'";
                    if (city.Equals("Toronto"))
                    {
                        postal = "," + "'M";
                    }
                    else
                    {
                        postal = "," + "'L";
                    }
                }
                else if (city.Equals("Victoria") || city.Equals("Vancouver"))
                {
                    personName = personName + ",'BC'";
                    postal = "," + "'V";
                }
                else if (city.Equals("Calgary") || city.Equals("Edmonton"))
                {
                    personName = personName + ",'AB'";
                    postal = "," + "'T";
                }
                else if (city.Equals("Regina"))
                {
                    personName = personName + ",'SK'";
                    postal = "," + "'S";
                }
                else if (city.Equals("Winnipeg"))
                {
                    personName = personName + ",'MB'";
                    postal = "," + "'R";
                }
                else if (city.Equals("Quebec City") || city.Equals("Montreal"))
                {
                    personName = personName + ",'QC'";
                    if (city.Equals("Quebec City"))
                        {
                        postal = "," + "'G";
                    }
                    else if (city.Equals("Montreal"))
                    {
                        postal = "," + "'H";
                    }
                }
                else if (city.Equals("Frediricton"))
                {
                    personName = personName + ",'NB'";
                    postal = "," + "'E";
                }
                else if (city.Equals("Halifax") || city.Equals("Sydney"))
                {
                    personName = personName + ",'NS'";
                    postal = "," + "'B";
                }
                else if (city.Equals("Charlottetown"))
                {
                    personName = personName + ",'PE'";
                    postal = "," + "'C";
                }
                else if (city.Equals("Iqaluit"))
                {
                    personName = personName + ",'NU'";
                    postal = "," + "'X";
                }
                else if (city.Equals("Whitehorse"))
                {
                    personName = personName + ",'YT'";
                    postal = "," + "'Y";
                }
                else if (city.Equals("Yellowknife"))
                {
                    personName = personName + ",'NT'";
                    postal = "," + "'X";
                }
                else
                {
                    personName = personName + ",'error'";
                }

                postal =postal+ randomNumber.Next(0, 10) + letters[randomNumber.Next(0, 20)] + randomNumber.Next(0, 10) + letters[randomNumber.Next(0, 20)] + randomNumber.Next(0, 10);
                personName = personName + postal+"'";

                phone = randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10);
                personName = personName + ",'" + phone+"'";
                if (randomNumber.Next(1, 4) == 2)
                {
                    phone = randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10);
                    personName = personName + ",'" + phone+"'";
                }
                else
                {
                    personName = personName + ",'null'" ;
                }

                fax =",'"+ randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + "-" + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10) + randomNumber.Next(0, 10);
                personName = personName + fax+"'";

                contact = randomNumber.Next(1, 5);
                if(contact==1)
                {
                    personName = personName + ",'E'";
                }
                else if (contact == 2)
                {
                    personName = personName + ",'F'";
                }
                else if (contact==3)
                {
                    personName = personName + ",'P'";
                }
                else if (contact == 4)
                {
                    personName = personName + ",'L'";
                }

                personName = personName + ");";
                if (!listOfNames.Contains(personName))
                {
                    listOfNames.Add(personName);
                }
            }
            return listOfNames;

        }

    }
}
